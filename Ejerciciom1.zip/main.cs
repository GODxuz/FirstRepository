using System;

class Program {
  public static void Main (string[] args) {
    Console.WriteLine ("Hello World");
  }
  Bicicleta Bicicleta1 = new Bicicleta();
  Bicicleta1.marca = "Oxford";
  Bicicleta1.modelo = "Kamikaze";
  Bicicleta1.color = "rojo";
  Bicicleta1.aro = 16;
  Bicicleta1.velocidades = 20;
}
class Bicicleta

{
    public string marca;
    public string modelo;
    public int aro;
    public int velocidades;
    public string color;
  
 //

    public void Acelerar()
    {
    
    }
    public void Frenar()
    {
      
    }
    public void CambioVelocidades()
    {
      
    }
}
